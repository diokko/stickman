<?php
Interface Attributes{
    public $current;
    public $init;
    public $max;
    public $min;
    const  $type = array["strength","life"];
}