<?php
Interface Items{
    public $name;
    public $price;
    const  $type = array["weapon","potion"];
}